import type { Metadata } from 'next'
import AnnouncementBar from '@/components/AnnouncementBar'
import Nav from '@/components/Nav'
import ProductsSection from '@/components/ProductsSection'
import Footer from '@/components/Footer'

export const metadata: Metadata = {
  title: 'Research Peptides',
  description: '40+ research-grade peptides, independently tested and cold-chain dispatched across the UK. Every batch has a public COA.',
}

export default function ProductsPage() {
  return (
    <>
      
      <Nav />
      <main>
        <div className="border-b" style={{ borderColor: '#E5EAF5', background: '#F3F5FB' }}>
          <div className="max-w-7xl mx-auto px-5 lg:px-10 py-14">
            <p className="text-[10px] font-bold uppercase tracking-[0.12em] mb-2" style={{ color: '#AAB3C8' }}>
              Catalogue
            </p>
            <h1
              className="text-[clamp(36px,5vw,60px)] font-bold tracking-[-0.03em] mb-3"
              style={{ fontFamily: 'var(--font-display)', color: '#0D0F14' }}
            >
              All Peptides
            </h1>
            <p className="text-[15px] font-light max-w-xl leading-[1.8]" style={{ color: '#626A85' }}>
              40+ research-grade compounds, independently verified by Eurofins UK, cold-chain dispatched. Every batch certificate is publicly searchable.
            </p>
          </div>
        </div>
        <ProductsSection showAll />
      </main>
      <Footer />
    </>
  )
}