import Nav from '@/components/Nav'
import Hero from '@/components/Hero'
import TrustBar from '@/components/TrustBar'
import ProductsSection from '@/components/ProductsSection'
import FeaturesSection from '@/components/FeaturesSection'
import ProcessSection from '@/components/ProcessSection'
import ReviewsSection from '@/components/ReviewsSection'
import NewsletterSection from '@/components/NewsletterSection'
import BlogSection from '@/components/BlogSection'
import Footer from '@/components/Footer'

export default function HomePage() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <ProductsSection />
        <TrustBar />
        <FeaturesSection />
        <ProcessSection />
        <ReviewsSection />
        <BlogSection />
        <NewsletterSection />
      </main>
      <Footer />
    </>
  )
}