'use client'
import { useState, useEffect, useRef } from 'react'
import { ShoppingBag, Search, Menu, X, ChevronDown, ArrowRight } from 'lucide-react'
import { useCart } from '@/lib/cartContext'
import { PRODUCTS } from '@/app/data'

const NAV_LINKS = [
  {
    label: 'Products', href: '/products', hasDropdown: true,
    items: [
      { label: 'All Peptides',     href: '/products',              sub: '40+ compounds' },
      { label: 'Metabolic',        href: '/products?cat=metabolic', sub: '8 products' },
      { label: 'Recovery',         href: '/products?cat=recovery',  sub: '7 products' },
      { label: 'Cognitive',        href: '/products?cat=cognitive', sub: '6 products' },
      { label: 'Hormonal',         href: '/products?cat=hormonal',  sub: '9 products' },
      { label: 'Bundles & Stacks', href: '/bundles',               sub: 'Save up to £9' },
    ],
  },
  { label: 'Lab Certificates', href: '/certificates', hasDropdown: false, items: [] },
  {
    label: 'Research Hub', href: '/research', hasDropdown: true,
    items: [
      { label: 'Research Guides',      href: '/research',            sub: 'Protocols & references' },
      { label: 'Published Studies',    href: '/research#studies',    sub: 'Peer-reviewed links' },
      { label: 'Reconstitution Calc',  href: '/tools#calculator',    sub: 'Instant dosage tool' },
    ],
  },
  { label: 'Tools', href: '/tools', hasDropdown: false, items: [] },
  { label: 'FAQ',   href: '/faq',   hasDropdown: false, items: [] },
]

export default function Nav() {
  const { totalQuantity, openCart } = useCart()
  const [mobileOpen,     setMobileOpen]     = useState(false)
  const [searchOpen,     setSearchOpen]     = useState(false)
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)
  const [searchQuery,    setSearchQuery]    = useState('')
  const [scrolled,       setScrolled]       = useState(false)
  const searchRef   = useRef<HTMLInputElement>(null)
  const dropTimer   = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    if (searchOpen) setTimeout(() => searchRef.current?.focus(), 50)
  }, [searchOpen])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { setSearchOpen(false); setMobileOpen(false) }
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); setSearchOpen(true) }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const searchResults = searchQuery.length > 1
    ? PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : []

  const openDrop  = (label: string) => { if (dropTimer.current) clearTimeout(dropTimer.current); setActiveDropdown(label) }
  const closeDrop = ()              => { dropTimer.current = setTimeout(() => setActiveDropdown(null), 120) }

  return (
    <>
      {/* ── Search overlay ── */}
      {searchOpen && (
        <div className="search-overlay" onClick={() => setSearchOpen(false)}>
          <div className="search-box mx-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 px-5 py-4 border-b border-[var(--border)]">
              <Search size={16} className="text-[var(--ink-40)] flex-shrink-0" />
              <input
                ref={searchRef}
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder='Search peptides — try "BPC-157" or "cognitive"'
                className="flex-1 text-[14px] outline-none bg-transparent text-[var(--ink)] placeholder:text-[var(--ink-40)]"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="text-[var(--ink-40)] hover:text-[var(--ink)]">
                  <X size={14} />
                </button>
              )}
              <kbd className="hidden sm:flex items-center text-[10px] font-medium text-[var(--ink-40)] border border-[var(--border)] px-1.5 py-0.5 rounded">
                ESC
              </kbd>
            </div>

            {searchResults.length > 0 ? (
              <div className="py-2">
                {searchResults.map(p => (
                  <a
                    key={p.id}
                    href={`/products/${p.slug}`}
                    onClick={() => setSearchOpen(false)}
                    className="flex items-center gap-3 px-5 py-3 hover:bg-[var(--gray-50)] transition-colors group"
                  >
                    <div
                      className="w-9 h-9 rounded-lg flex-shrink-0 flex items-center justify-center text-[11px] font-bold"
                      style={{ background: p.color.bg, color: p.color.accent }}
                    >
                      {p.shortName.slice(0, 3)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-[13px] font-semibold text-[var(--ink)] group-hover:text-[var(--blue)] transition-colors">{p.name}</div>
                      <div className="text-[11px] text-[var(--ink-40)]">{p.category}</div>
                    </div>
                    <div className="text-[13px] font-semibold text-[var(--ink)]">£{p.price.toFixed(2)}</div>
                  </a>
                ))}
                <div className="px-5 py-3 border-t border-[var(--border)]">
                  <a
                    href={`/products?q=${searchQuery}`}
                    className="text-[12px] text-[var(--blue)] font-semibold flex items-center gap-1.5 hover:gap-2.5 transition-all"
                    onClick={() => setSearchOpen(false)}
                  >
                    View all results for "{searchQuery}" <ArrowRight size={12} />
                  </a>
                </div>
              </div>
            ) : searchQuery.length > 1 ? (
              <div className="py-10 text-center text-[13px] text-[var(--ink-40)]">
                No peptides found for "{searchQuery}"
              </div>
            ) : (
              <div className="px-5 py-4">
                <div className="text-[10px] font-bold uppercase tracking-widest text-[var(--ink-40)] mb-3">Popular searches</div>
                <div className="flex flex-wrap gap-2">
                  {['BPC-157', 'GLP-1', 'TB-500', 'Cognitive', 'Recovery', 'Anti-ageing'].map(q => (
                    <button
                      key={q}
                      onClick={() => setSearchQuery(q)}
                      className="text-[12px] text-[var(--ink-60)] border border-[var(--border)] px-3 py-1.5 rounded-full hover:border-[var(--blue-mid)] hover:text-[var(--blue)] transition-colors"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Announcement bar ── */}
      <div className="bg-[var(--blue)] text-white text-[11.5px] font-medium text-center py-2 px-4 tracking-wide">
        🧪 &nbsp;Free UK tracked shipping on orders over £80 &nbsp;·&nbsp; HPLC-verified, Eurofins-tested &nbsp;·&nbsp;
        <a href="/certificates" className="underline underline-offset-2 opacity-80 hover:opacity-100 ml-1">View all COAs →</a>
      </div>

      {/* ── Main nav ── */}
      <nav
        className={`sticky top-0 z-50 bg-white transition-all duration-200 ${
          scrolled
            ? 'shadow-[0_2px_20px_rgba(13,15,20,0.08)] border-b border-transparent'
            : 'border-b border-[var(--border)]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-5 lg:px-10 h-[64px] flex items-center justify-between gap-6">

          {/* Logo */}
          <a href="/" className="flex items-center gap-2.5 flex-shrink-0 group">
            <span className="text-[22px] font-bold tracking-tight text-[var(--ink)]" style={{ fontFamily: 'var(--font-display)' }}>
              PepcoLab
            </span>
          </a>

          {/* Center links */}
          <div className="hidden lg:flex items-center gap-0.5">
            {NAV_LINKS.map((link) => (
              <div
                key={link.label}
                className="relative"
                onMouseEnter={() => link.hasDropdown && openDrop(link.label)}
                onMouseLeave={() => link.hasDropdown && closeDrop()}
              >
                <a
                  href={link.href}
                  className="flex items-center gap-1 px-3.5 py-2.5 text-[13.5px] font-medium text-[var(--ink-60)] hover:text-[var(--ink)] rounded-lg hover:bg-[var(--gray-50)] transition-all"
                >
                  {link.label}
                  {link.hasDropdown && (
                    <ChevronDown
                      size={11}
                      className={`opacity-40 transition-transform duration-150 ${activeDropdown === link.label ? 'rotate-180' : ''}`}
                    />
                  )}
                </a>

                {link.hasDropdown && activeDropdown === link.label && link.items.length > 0 && (
                  <div
                    className="absolute top-full left-0 pt-2 z-50"
                    onMouseEnter={() => openDrop(link.label)}
                    onMouseLeave={closeDrop}
                  >
                    <div className="bg-white border border-[var(--border)] rounded-2xl shadow-[0_12px_40px_rgba(13,15,20,0.12)] overflow-hidden min-w-[230px] py-2">
                      {link.items.map(item => (
                        <a
                          key={item.label}
                          href={item.href}
                          className="flex flex-col px-4 py-2.5 hover:bg-[var(--blue-light)] transition-colors group"
                        >
                          <span className="text-[13px] font-semibold text-[var(--ink)] group-hover:text-[var(--blue)]">{item.label}</span>
                          {item.sub && <span className="text-[11px] text-[var(--ink-40)] mt-0.5">{item.sub}</span>}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSearchOpen(true)}
              className="hidden sm:flex items-center gap-2 text-[12.5px] font-medium text-[var(--ink-40)] border border-[var(--border)] px-3.5 py-2 rounded-lg hover:border-[var(--gray-300)] hover:text-[var(--ink-60)] transition-all"
            >
              <Search size={13} />
              <span className="hidden md:block">Search</span>
              <kbd className="hidden lg:flex items-center text-[10px] border border-[var(--border)] px-1.5 rounded-md">⌘K</kbd>
            </button>

            <button
              onClick={openCart}
              className="relative flex items-center justify-center w-10 h-10 rounded-xl hover:bg-[var(--gray-50)] transition-colors text-[var(--ink-60)] hover:text-[var(--ink)]"
              aria-label={`Cart (${totalQuantity} items)`}
            >
              <ShoppingBag size={18} />
              {totalQuantity > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4.5 h-4.5 min-w-[18px] min-h-[18px] bg-[var(--blue)] text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {totalQuantity > 9 ? '9+' : totalQuantity}
                </span>
              )}
            </button>

            <a href="/products" className="btn btn-blue hidden sm:inline-flex py-2.5 px-5 text-[13px]">
              Shop Now
            </a>

            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden w-10 h-10 rounded-xl hover:bg-[var(--gray-50)] flex items-center justify-center text-[var(--ink)]"
            >
              {mobileOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="lg:hidden border-t border-[var(--border)] bg-white">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="flex items-center justify-between px-5 py-4 text-[14px] font-medium text-[var(--ink-60)] hover:text-[var(--blue)] hover:bg-[var(--blue-light)] border-b border-[var(--border)] transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
                {link.hasDropdown && <ChevronDown size={14} className="opacity-30" />}
              </a>
            ))}
            <div className="p-4 flex gap-2.5">
              <button
                onClick={() => { setMobileOpen(false); setSearchOpen(true) }}
                className="btn btn-ghost flex-1 py-3"
              >
                <Search size={14} /> Search
              </button>
              <a
                href="/products"
                className="btn btn-blue flex-1 py-3"
                onClick={() => setMobileOpen(false)}
              >
                Shop All
              </a>
            </div>
          </div>
        )}
      </nav>
    </>
  )
}