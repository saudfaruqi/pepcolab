'use client'
import { useEffect, useRef, useState } from 'react'
import { ArrowRight, ArrowUpRight, Star, Upload, ChevronRight, Volume2, VolumeX } from 'lucide-react'

// ── Replace this URL with your own hosted video ──
const HERO_VIDEO = 'https://videos.pexels.com/video-files/3195394/3195394-uhd_2560_1440_25fps.mp4'
const HERO_VIDEO_POSTER = 'https://images.unsplash.com/photo-1563213126-a4273aed2016?w=900&q=85&auto=format&fit=crop'

const STATS = [
  { value: 2.3, unit: 'K+', label: 'Prescriptions filled', decimals: 1 },
  { value: 3.5, unit: 'K+', label: 'Customers served',     decimals: 1 },
  { value: 98,  unit: '%',  label: 'Client satisfaction',  decimals: 0 },
]

const CATEGORIES = [
  { label: 'Allergy & Sinus',        img: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=200&q=75&auto=format&fit=crop&crop=center' },
  { label: 'Digestive Health',       img: 'https://images.unsplash.com/photo-1559757175-5700dde675bc?w=200&q=75&auto=format&fit=crop&crop=center' },
  { label: 'Pain & Fever',           img: 'https://images.unsplash.com/photo-1576671414121-aa2d60f06f93?w=200&q=75&auto=format&fit=crop&crop=center' },
  { label: 'Cold & Flu Relief',      img: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=200&q=75&auto=format&fit=crop&crop=center' },
  { label: 'Vitamins & Supplements', img: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=200&q=75&auto=format&fit=crop&crop=center' },
  { label: 'Skin & Hair Care',       img: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=200&q=75&auto=format&fit=crop&crop=center' },
]

export default function Hero() {
  const leftRef  = useRef<HTMLDivElement>(null)
  const rightRef = useRef<HTMLDivElement>(null)
  const statsRef = useRef<HTMLDivElement>(null)
  const catRef   = useRef<HTMLDivElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [counts, setCounts] = useState([0, 0, 0])
  const [muted, setMuted] = useState(true)

  const toggleMute = () => {
    if (!videoRef.current) return
    videoRef.current.muted = !muted
    setMuted(prev => !prev)
  }

  useEffect(() => {
    const els = [
      { el: leftRef.current,  delay: 60  },
      { el: rightRef.current, delay: 200 },
      { el: statsRef.current, delay: 330 },
      { el: catRef.current,   delay: 450 },
    ]
    els.forEach(({ el, delay }) => {
      if (!el) return
      el.style.opacity = '0'
      el.style.transform = 'translateY(22px)'
      setTimeout(() => {
        el.style.transition = 'opacity 0.7s cubic-bezier(0.22,1,0.36,1), transform 0.7s cubic-bezier(0.22,1,0.36,1)'
        el.style.opacity = '1'
        el.style.transform = 'translateY(0)'
      }, delay)
    })

    // Counter animation
    setTimeout(() => {
      const duration = 1400
      const start = Date.now()
      const targets = STATS.map(s => s.value)
      const tick = () => {
        const elapsed = Date.now() - start
        const progress = Math.min(elapsed / duration, 1)
        const ease = 1 - Math.pow(1 - progress, 3)
        setCounts(targets.map(t => parseFloat((t * ease).toFixed(1))))
        if (progress < 1) requestAnimationFrame(tick)
        else setCounts(targets)
      }
      requestAnimationFrame(tick)
    }, 600)
  }, [])

  return (
    <section className="bg-white overflow-hidden">
      <div className="max-w-[1320px] mx-auto px-5 lg:px-8">

        {/* ── TOP SPLIT GRID ── */}
        <div className="grid lg:grid-cols-2 gap-4 pt-12 pb-0">

          {/* LEFT card */}
          <div
            ref={leftRef}
            className="flex flex-col justify-between rounded-[22px] p-8 lg:p-10 relative overflow-hidden"
            style={{ background: '#F3F5FB', minHeight: '480px' }}
          >
            {/* Subtle blue radial */}
            <div className="absolute top-[-20px] right-[-20px] w-80 h-80 rounded-full pointer-events-none"
              style={{ background: 'radial-gradient(circle, rgba(26,86,219,0.07) 0%, transparent 70%)' }} />

            <div className="relative z-10">
              {/* H1 */}
              <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(40px,5.5vw,68px)', fontWeight: 800, lineHeight: 1.0, letterSpacing: '-0.04em', color: '#0D0F14', marginBottom: '20px' }}>
                Your Smart<br />
                And Trusted<br />
                <span style={{ background: 'linear-gradient(130deg,#1A56DB 0%,#60A5FA 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                  Health Partner
                </span>
              </h1>

              <p style={{ fontSize: '15.5px', lineHeight: 1.75, color: '#626A85', fontWeight: 400, maxWidth: '360px', marginBottom: '32px' }}>
                Wellness at your fingertips with 2-hour delivery. Licensed pharmacists, FDA-approved only.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap gap-3">
                <a href="/products"
                  className="inline-flex items-center gap-2.5 text-white font-semibold rounded-[11px] px-6 py-3.5 text-[14px] transition-all duration-200"
                  style={{ background: 'linear-gradient(135deg,#1A56DB,#2563EB)', boxShadow: '0 4px 18px rgba(26,86,219,0.38)' }}
                  onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.transform='translateY(-1px)'; el.style.boxShadow='0 8px 26px rgba(26,86,219,0.5)' }}
                  onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.transform=''; el.style.boxShadow='0 4px 18px rgba(26,86,219,0.38)' }}
                >
                  <Upload size={15} strokeWidth={2.5} />
                  Upload Prescription
                </a>
                <a href="/products"
                  className="inline-flex items-center gap-2 bg-white text-[#0D0F14] font-semibold rounded-[11px] px-6 py-3.5 text-[14px] border transition-all duration-200 hover:shadow-md"
                  style={{ borderColor: '#DDE3F0' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = '#A8BADE' }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = '#DDE3F0' }}
                >
                  Browse Products
                  <ArrowRight size={14} strokeWidth={2.5} />
                </a>
              </div>
            </div>

            {/* Trust logos — bottom */}
            <div className="relative z-10 mt-10 pt-6" style={{ borderTop: '1px solid rgba(13,15,20,0.08)' }}>
              <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-[#AAB3C8] mb-4">Certified & Accredited</p>
              <div className="flex items-center gap-7 flex-wrap">
                {['NABP', 'Vipps', 'HIPAA', 'FDA'].map(logo => (
                  <span key={logo} style={{ fontFamily: 'var(--font-display)', fontSize: '15px', fontWeight: 900, color: '#9BA6BC', letterSpacing: '-0.03em' }}>
                    {logo}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT: video + stat cards below */}
          <div ref={rightRef} className="flex flex-col gap-4">

            {/* ── VIDEO CARD ── */}
            <div className="relative rounded-[22px] overflow-hidden group flex-1" style={{ minHeight: '320px' }}>
              <video
                ref={videoRef}
                src={HERO_VIDEO}
                poster={HERO_VIDEO_POSTER}
                autoPlay
                muted
                loop
                playsInline
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.025]"
                style={{ objectPosition: 'center 40%' }}
              />

              {/* Dark gradient bottom overlay */}
              <div className="absolute inset-0 pointer-events-none"
                style={{ background: 'linear-gradient(to top, rgba(10,12,20,0.55) 0%, rgba(10,12,20,0.1) 40%, transparent 70%)' }} />

              {/* Mute / unmute button — bottom-left */}
              <button
                onClick={toggleMute}
                aria-label={muted ? 'Unmute video' : 'Mute video'}
                className="absolute bottom-4 left-4 flex items-center justify-center rounded-full backdrop-blur-md transition-all duration-200 hover:scale-110 active:scale-95"
                style={{
                  width: '36px', height: '36px',
                  background: 'rgba(255,255,255,0.18)',
                  border: '1px solid rgba(255,255,255,0.28)',
                  color: '#fff',
                }}
              >
                {muted
                  ? <VolumeX size={15} strokeWidth={2.2} />
                  : <Volume2 size={15} strokeWidth={2.2} />
                }
              </button>

              {/* Floating: ratings bottom-right */}
              <div className="absolute bottom-4 right-4 bg-white/[0.96] backdrop-blur-md rounded-2xl px-3.5 py-2.5 shadow-[0_4px_20px_rgba(0,0,0,0.12)] flex items-center gap-2">
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => <Star key={i} size={11} className="text-amber-400 fill-amber-400" />)}
                </div>
                <span style={{ fontSize: '12px', fontWeight: 700, color: '#0D0F14' }}>4.9</span>
                <span style={{ fontSize: '10.5px', fontWeight: 500, color: '#9BA6BC' }}>· 10k+ reviews</span>
              </div>

            </div>

            {/* Stat cards row */}
            <div ref={statsRef} className="grid grid-cols-3 gap-4">
              {STATS.map((s, i) => (
                <div
                  key={s.label}
                  className="rounded-[18px] flex flex-col gap-1 px-5 py-5 cursor-default transition-all duration-200 hover:-translate-y-0.5 group"
                  style={{ background: '#F3F5FB' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = '#EBF2FF' }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = '#F3F5FB' }}
                >
                  <div className="flex items-end gap-0.5 leading-none">
                    <span
                      style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(26px,3.2vw,38px)', fontWeight: 900, color: '#0D0F14', letterSpacing: '-0.04em', lineHeight: 1, transition: 'color 0.2s' }}
                      className="group-hover:text-[#1A56DB]"
                    >
                      {s.decimals === 1 ? counts[i].toFixed(1) : Math.round(counts[i])}
                    </span>
                    <span style={{ fontSize: '16px', fontWeight: 800, color: '#1A56DB', marginBottom: '1px' }}>{s.unit}</span>
                  </div>
                  <span style={{ fontSize: '11.5px', fontWeight: 500, color: '#9BA6BC', lineHeight: 1.4 }}>{s.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ══════════════════════════════════════
            POPULAR CATEGORIES strip
        ══════════════════════════════════════ */}
        <div ref={catRef} className="mt-5 py-8">
          <div className="flex items-center justify-between mb-4">
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '15.5px', fontWeight: 700, color: '#0D0F14' }}>
              Popular Categories
            </h2>
            <a href="/products" style={{ fontSize: '12.5px', fontWeight: 600, color: '#1A56DB' }} className="flex items-center gap-1 hover:gap-2 transition-all">
              See all <ChevronRight size={13} />
            </a>
          </div>

          <div className="flex gap-2.5 overflow-x-auto py-2" style={{ scrollbarWidth: 'none' }}>
            {CATEGORIES.map((cat) => (
              <a
                key={cat.label}
                href={`/products?cat=${encodeURIComponent(cat.label)}`}
                className="group flex-shrink-0 flex items-center rounded-full border transition-all duration-200 overflow-hidden bg-white"
                style={{ borderColor: '#E5EAF5', gap: 0 }}
                onMouseEnter={e => {
                  const el = e.currentTarget as HTMLElement
                  el.style.borderColor = '#1A56DB'
                  el.style.boxShadow = '0 4px 18px rgba(26,86,219,0.16)'
                  el.style.transform = 'translateY(-1px)'
                }}
                onMouseLeave={e => {
                  const el = e.currentTarget as HTMLElement
                  el.style.borderColor = '#E5EAF5'
                  el.style.boxShadow = ''
                  el.style.transform = ''
                }}
              >
                {/* Thumbnail */}
                <div className="w-[46px] h-[46px] rounded-full overflow-hidden flex-shrink-0 m-[3px]">
                  <img
                    src={cat.img}
                    alt={cat.label}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-800"
                  />
                </div>

                {/* Label */}
                <span className="pl-3 pr-2 whitespace-nowrap font-semibold transition-colors duration-200"
                  style={{ fontSize: '13px', color: '#2B3252' }}
                >
                  {cat.label}
                </span>

                {/* Arrow circle */}
                <div
                  className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mr-3 transition-all duration-200"
                  style={{ background: '#F0F3FA' }}
                >
                  <ArrowUpRight size={11} style={{ color: '#9BA6BC' }} />
                </div>
              </a>
            ))}
          </div>
        </div>

      </div>
      <style>{`.scrollbar-hide::-webkit-scrollbar{display:none}`}</style>
    </section>
  )
}