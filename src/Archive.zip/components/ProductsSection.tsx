'use client'
import { useRef, useEffect, useState } from 'react'
import { ArrowRight, ShoppingCart, CheckCircle, SlidersHorizontal } from 'lucide-react'
import { PRODUCTS } from '@/app/data'
import { useCart } from '@/lib/cartContext'

interface Props { showAll?: boolean }

export default function ProductsSection({ showAll = false }: Props) {
  const headRef = useRef<HTMLDivElement>(null)
  const gridRef = useRef<HTMLDivElement>(null)
  const [addedIds, setAddedIds] = useState<Set<string>>(new Set())
  const [filter, setFilter] = useState<string>('all')
  const { addItem } = useCart()

  const categories = ['all', ...Array.from(new Set(PRODUCTS.map(p => p.category)))]

  const filtered = PRODUCTS
    .filter(p => filter === 'all' || p.category === filter)
    .filter(p => showAll || p.inStock)
    .slice(0, showAll ? undefined : 4)

  useEffect(() => {
    const animate = (el: HTMLElement | null, delay = 0) => {
      if (!el) return
      el.style.opacity = '0'
      el.style.transform = 'translateY(18px)'
      const obs = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              el.style.transition = 'opacity 0.6s cubic-bezier(0.22,1,0.36,1), transform 0.6s cubic-bezier(0.22,1,0.36,1)'
              el.style.opacity = '1'
              el.style.transform = 'translateY(0)'
            }, delay)
            obs.disconnect()
          }
        },
        { threshold: 0.08 }
      )
      obs.observe(el)
    }
    animate(headRef.current, 0)
    animate(gridRef.current, 80)
  }, [])

  const handleAdd = (p: typeof PRODUCTS[0]) => {
    addItem(
      p.variantId ?? `gid://shopify/ProductVariant/${p.id}`,
      p.name,
      p.mg,
      p.price,
      p.slug
    )
    setAddedIds(prev => new Set([...prev, p.id]))
    setTimeout(() => {
      setAddedIds(prev => { const n = new Set(prev); n.delete(p.id); return n })
    }, 1800)
  }

  return (
    <section className="py-12 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 lg:px-8">

        {/* Header */}
        <div ref={headRef} className="flex flex-col gap-5 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h2
                className="text-[clamp(22px,3vw,30px)] font-bold tracking-tight"
                style={{ fontFamily: 'var(--font-display)', color: '#0D0F14' }}
              >
                {showAll ? 'All Peptides' : 'Top Products'}
              </h2>
            </div>
            {!showAll && (
              <a
                href="/products"
                className="hidden sm:flex items-center gap-1.5 text-[13px] font-semibold transition-colors duration-150"
                style={{ color: '#1A56DB' }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.gap = '10px' }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.gap = '6px' }}
              >
                View all <ArrowRight size={14} />
              </a>
            )}
          </div>

          {/* Category filter pills */}
          {showAll && (
            <div className="flex items-center gap-2 flex-wrap">
              <SlidersHorizontal size={13} style={{ color: '#AAB3C8' }} />
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className="text-[12px] font-semibold capitalize px-3.5 py-1.5 rounded-full border transition-all duration-150"
                  style={
                    filter === cat
                      ? { background: '#1A56DB', color: '#fff', borderColor: '#1A56DB' }
                      : { background: '#fff', color: '#626A85', borderColor: '#E5EAF5' }
                  }
                  onMouseEnter={e => {
                    if (filter === cat) return
                    const el = e.currentTarget as HTMLElement
                    el.style.borderColor = '#A8BADE'
                    el.style.color = '#0D0F14'
                  }}
                  onMouseLeave={e => {
                    if (filter === cat) return
                    const el = e.currentTarget as HTMLElement
                    el.style.borderColor = '#E5EAF5'
                    el.style.color = '#626A85'
                  }}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {filtered.map((p) => {
            const isAdded = addedIds.has(p.id)
            return (
              <div
                key={p.id}
                className="group flex flex-col rounded-[18px] border overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_8px_32px_rgba(13,15,20,0.08)]"
                style={{ background: '#fff', borderColor: '#E5EAF5' }}
              >
                {/* Visual area */}
                <a href={`/products/${p.slug}`} className="block relative">
                  <div
                    className="relative h-[160px] flex items-center justify-center overflow-hidden"
                    style={{ background: '#F3F5FB' }}
                  >
                    <div
                      className="w-20 h-20 rounded-2xl flex items-center justify-center transition-transform duration-500 group-hover:scale-105"
                      style={{ background: '#EBF2FF' }}
                    >
                      <span
                        style={{
                          fontFamily: 'var(--font-display)',
                          fontSize: '19px',
                          fontWeight: 800,
                          color: '#1A56DB',
                          letterSpacing: '-0.04em',
                        }}
                      >
                        {(p.shortName ?? p.name).slice(0, 3)}
                      </span>
                    </div>

                    {/* Badges */}
                    {p.badge && (
                      <div className="absolute top-3 left-3">
                        <span
                          className="text-[10px] font-semibold uppercase tracking-wider px-2 py-1 rounded-md"
                          style={{
                            background: p.badge === 'popular' ? '#1A56DB'
                              : p.badge === 'bestseller' ? '#0D0F14'
                              : p.badge === 'new' ? '#7C3AED'
                              : '#C05621',
                            color: '#fff',
                          }}
                        >
                          {p.badge}
                        </span>
                      </div>
                    )}
                    {p.oldPrice && (
                      <div className="absolute top-3 right-3">
                        <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-1 rounded-md bg-red-500 text-white">
                          Sale
                        </span>
                      </div>
                    )}
                    {!p.inStock && (
                      <div className="absolute inset-0 flex items-center justify-center" style={{ background: 'rgba(243,245,251,0.7)' }}>
                        <span className="text-[11px] font-semibold tracking-wide" style={{ color: '#AAB3C8' }}>Out of stock</span>
                      </div>
                    )}
                  </div>
                </a>

                {/* Info */}
                <div className="p-5 flex flex-col flex-1">
                  <div className="text-[10px] font-bold uppercase tracking-[0.1em] mb-1" style={{ color: '#AAB3C8' }}>
                    {p.category}
                  </div>
                  <a href={`/products/${p.slug}`}>
                    <h3
                      className="text-[14px] font-semibold leading-snug mb-1.5 transition-colors duration-150 group-hover:text-[#1A56DB]"
                      style={{ fontFamily: 'var(--font-display)', color: '#0D0F14' }}
                    >
                      {p.name}
                    </h3>
                  </a>
                  <p className="text-[12px] leading-[1.7] flex-1 mb-4 lg:flex hidden" style={{ color: '#626A85' }}>
                    {p.description}
                  </p>


                  {/* Price + Add */}
                  <div className="flex items-center justify-between pt-4" style={{ borderTop: '1px solid #E5EAF5' }}>
                    <div>
                      <div
                        className="text-[17px] font-bold tracking-tight"
                        style={{ fontFamily: 'var(--font-display)', color: '#0D0F14' }}
                      >
                        £{p.price.toFixed(2)}
                      </div>
                      {p.oldPrice && (
                        <div className="text-[11px] line-through" style={{ color: '#AAB3C8' }}>
                          £{p.oldPrice.toFixed(2)}
                        </div>
                      )}
                    </div>
                    <button
                      onClick={() => handleAdd(p)}
                      disabled={!p.inStock}
                      className="flex items-center gap-1.5 text-[12px] font-semibold px-2.5 py-2 sm:px-3.5 rounded-[9px] transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
                      style={
                        !p.inStock
                          ? { background: '#F3F5FB', color: '#AAB3C8' }
                          : isAdded
                          ? { background: '#EAF3DE', color: '#3B6D11' }
                          : { background: '#1A56DB', color: '#fff', boxShadow: '0 4px 14px rgba(26,86,219,0.3)' }
                      }
                      onMouseEnter={e => {
                        if (!p.inStock || isAdded) return
                        const el = e.currentTarget as HTMLElement
                        el.style.transform = 'translateY(-1px)'
                        el.style.boxShadow = '0 6px 20px rgba(26,86,219,0.45)'
                      }}
                      onMouseLeave={e => {
                        if (!p.inStock || isAdded) return
                        const el = e.currentTarget as HTMLElement
                        el.style.transform = ''
                        el.style.boxShadow = '0 4px 14px rgba(26,86,219,0.3)'
                      }}
                    >
                      {isAdded
                        ? <><CheckCircle size={12} /><span className="hidden sm:inline"> Added!</span></>
                        : p.inStock
                        ? <><ShoppingCart size={12} /><span className="hidden sm:inline"> Add to cart</span></>
                        : <span className="hidden sm:inline">OOS</span>
                      }
                    </button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Mobile view-all */}
        {!showAll && (
          <div className="mt-8 flex justify-center sm:hidden">
            <a
              href="/products"
              className="flex items-center gap-2 text-[13px] font-semibold px-5 py-3 rounded-[11px] border transition-all duration-200"
              style={{ borderColor: '#DDE3F0', color: '#0D0F14' }}
            >
              View all products <ArrowRight size={14} />
            </a>
          </div>
        )}

      </div>
    </section>
  )
}