'use client'
import { ShoppingCart, CheckCircle, AlertCircle } from 'lucide-react'
import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import type { Product } from '@/app/data'
import { useCart } from '@/lib/cartContext'

interface Props { product: Product; featured?: boolean }

export default function ProductCard({ product: p, featured = false }: Props) {
  const [added, setAdded] = useState(false)
  const { addItem } = useCart()
  const cardRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const el = cardRef.current
    if (!el) return
    el.style.opacity = '0'
    el.style.transform = 'translateY(20px)'
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.style.transition = 'opacity 0.6s cubic-bezier(0.22,1,0.36,1), transform 0.6s cubic-bezier(0.22,1,0.36,1)'
          el.style.opacity = '1'
          el.style.transform = 'translateY(0)'
          obs.disconnect()
        }
      },
      { threshold: 0.08 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])

  const handleAdd = async (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation()
    if (!p.inStock || added) return
    setAdded(true)
    await addItem(p.variantId ?? `gid://shopify/ProductVariant/${p.id}`, p.name, p.mg, p.price, p.slug)
    setTimeout(() => setAdded(false), 2200)
  }

  return (
    <article
      ref={cardRef}
      className={`group flex flex-col rounded-[18px] border overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_8px_32px_rgba(13,15,20,0.08)] ${featured ? 'border-[#1A56DB]/20' : 'border-[#E5EAF5]'}`}
      style={{ background: '#fff' }}
    >
      {/* Image / Visual area */}
      <Link href={`/products/${p.slug}`} className="block relative">
        <div
          className="relative h-[180px] overflow-hidden flex items-center justify-center"
          style={{ background: '#F3F5FB' }}
        >
          {/* Monogram placeholder — clean, no image noise */}
          <div
            className="w-24 h-24 rounded-2xl flex items-center justify-center"
            style={{ background: '#EBF2FF' }}
          >
            <span
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '22px',
                fontWeight: 800,
                color: '#1A56DB',
                letterSpacing: '-0.04em',
              }}
            >
              {p.shortName?.slice(0, 3) ?? p.name.slice(0, 3)}
            </span>
          </div>

          {/* Badges */}
          <div className="absolute top-3 left-3 flex gap-1.5 z-10">
            {p.badge && p.inStock && (
              <span
                className="text-[10px] font-semibold uppercase tracking-wider px-2 py-1 rounded-md"
                style={{
                  background: p.badge === 'popular' ? '#1A56DB'
                    : p.badge === 'bestseller' ? '#0D0F14'
                    : p.badge === 'new' ? '#7C3AED'
                    : '#C05621',
                  color: '#fff',
                }}
              >
                {p.badge}
              </span>
            )}
            {!p.inStock && (
              <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-1 rounded-md bg-[#0D0F14]/10 text-[#626A85]">
                Out of stock
              </span>
            )}
          </div>

          {p.oldPrice && (
            <div className="absolute top-3 right-3 z-10">
              <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-1 rounded-md bg-red-500 text-white">
                Sale
              </span>
            </div>
          )}

          {p.inStock && p.stockCount <= 15 && (
            <div
              className="absolute bottom-3 right-3 flex items-center gap-1 text-[10px] font-semibold rounded-full px-2.5 py-1 z-10"
              style={{ background: '#FEF3C7', color: '#92400E' }}
            >
              <AlertCircle size={9} />
              {p.stockCount} left
            </div>
          )}
        </div>
      </Link>

      {/* Content */}
      <div className="flex flex-col flex-1 p-5">
        <div
          className="text-[10px] font-bold tracking-[0.1em] uppercase mb-1.5"
          style={{ color: '#AAB3C8' }}
        >
          {p.category}
        </div>

        <Link href={`/products/${p.slug}`}>
          <h3
            className="text-[14px] font-semibold leading-snug mb-1.5 transition-colors duration-150 group-hover:text-[#1A56DB]"
            style={{ color: '#0D0F14', fontFamily: 'var(--font-display)' }}
          >
            {p.name}
          </h3>
        </Link>

        <p className="text-[12px] leading-[1.7] flex-1 mb-4" style={{ color: '#626A85' }}>
          {p.description}
        </p>

        {/* Price + CTA */}
        <div className="flex items-center justify-between pt-4" style={{ borderTop: '1px solid #E5EAF5' }}>
          <div className="flex items-baseline gap-1.5">
            {p.oldPrice && (
              <span className="text-[12px] line-through" style={{ color: '#AAB3C8' }}>
                £{p.oldPrice.toFixed(2)}
              </span>
            )}
            <span
              className="text-[18px] font-semibold tracking-tight"
              style={{ fontFamily: 'var(--font-display)', color: '#0D0F14' }}
            >
              £{p.price.toFixed(2)}
            </span>
          </div>

          <button
            onClick={handleAdd}
            disabled={!p.inStock}
            className="flex items-center gap-1.5 text-[12px] font-semibold px-3.5 py-2 rounded-[9px] transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
            style={
              !p.inStock
                ? { background: '#F3F5FB', color: '#AAB3C8' }
                : added
                ? { background: '#EAF3DE', color: '#3B6D11' }
                : { background: '#1A56DB', color: '#fff', boxShadow: '0 4px 14px rgba(26,86,219,0.3)' }
            }
            onMouseEnter={e => {
              if (!p.inStock || added) return
              const el = e.currentTarget as HTMLElement
              el.style.transform = 'translateY(-1px)'
              el.style.boxShadow = '0 6px 20px rgba(26,86,219,0.45)'
            }}
            onMouseLeave={e => {
              const el = e.currentTarget as HTMLElement
              el.style.transform = ''
              el.style.boxShadow = added ? '' : !p.inStock ? '' : '0 4px 14px rgba(26,86,219,0.3)'
            }}
          >
            {added
              ? <><CheckCircle size={12} /> Added</>
              : p.inStock
              ? <><ShoppingCart size={12} /> Add</>
              : 'OOS'
            }
          </button>
        </div>
      </div>
    </article>
  )
}