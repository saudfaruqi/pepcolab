import { Phone, Mail, MapPin, Youtube, Instagram, Twitter, Linkedin, Facebook } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-[var(--ink)] text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">

        {/* Brand */}
        <div className="flex flex-col gap-5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[var(--blue)] flex items-center justify-center">
              <span className="text-white text-[12px] font-bold" style={{ fontFamily: 'var(--font-display)' }}>P</span>
            </div>
            <span className="text-[19px] font-bold tracking-tight" style={{ fontFamily: 'var(--font-display)' }}>PepcoLab</span>
          </div>
          <p className="text-[13px] text-[rgba(255,255,255,0.5)] leading-relaxed">
            Research-grade peptides, independently verified by Eurofins UK. Cold-chain dispatched across the United Kingdom.
          </p>
          <div className="flex items-center gap-2">
            {[Facebook, Instagram, Twitter, Linkedin, Youtube].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors bg-white/10 hover:bg-[var(--blue)]"
              >
                <Icon size={14} />
              </a>
            ))}
          </div>
        </div>

        {/* Pages */}
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-[rgba(255,255,255,0.35)] mb-5">Pages</div>
          <div className="flex flex-col gap-2.5">
            {['Home', 'Products', 'Lab Certificates', 'Research Hub', 'Tools', 'FAQ', 'Privacy Policy'].map(page => (
              <a key={page} href="#" className="text-[13px] text-[rgba(255,255,255,0.6)] hover:text-white transition-colors">
                {page}
              </a>
            ))}
          </div>
        </div>

        {/* Utility */}
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-[rgba(255,255,255,0.35)] mb-5">Utility Pages</div>
          <div className="flex flex-col gap-2.5">
            {['Style Guide', 'Instructions', 'Licenses', 'Changelog', 'Coming Soon', 'Error 404'].map(page => (
              <a key={page} href="#" className="text-[13px] text-[rgba(255,255,255,0.6)] hover:text-white transition-colors">
                {page}
              </a>
            ))}
          </div>
        </div>

        {/* Contact */}
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-[rgba(255,255,255,0.35)] mb-5">Available 24/7 Support</div>
          <div className="flex flex-col gap-4">
            <a href="tel:+13005550825" className="flex items-center gap-3 group">
              <div className="w-9 h-9 rounded-xl bg-[var(--blue)] flex items-center justify-center flex-shrink-0 group-hover:bg-[var(--blue-dark)] transition-colors">
                <Phone size={15} />
              </div>
              <div>
                <div className="text-[10px] text-[rgba(255,255,255,0.35)] font-medium uppercase tracking-wider">Phone</div>
                <div className="text-[13px] text-[rgba(255,255,255,0.75)] font-medium">+1 (300) 555-0825</div>
              </div>
            </a>
            <a href="mailto:info@pepcolab.com" className="flex items-center gap-3 group">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors" style={{ background: 'rgba(255,255,255,0.08)' }}>
                <Mail size={15} />
              </div>
              <div>
                <div className="text-[10px] text-[rgba(255,255,255,0.35)] font-medium uppercase tracking-wider">Email</div>
                <div className="text-[13px] text-[rgba(255,255,255,0.75)] font-medium">info@pepcolab.com</div>
              </div>
            </a>
          </div>
        </div>

      </div>

      {/* Bottom bar */}
      <div className="border-t border-[rgba(255,255,255,0.08)]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div
            className="text-[clamp(80px,9vw,90px)] font-black tracking-[-0.05em] leading-none"
            style={{ fontFamily: 'var(--font-display)', color: 'rgba(255,255,255,0.06)' }}
          >
            PEPCOLAB
          </div>
          <p className="text-[11.5px] text-[rgba(255,255,255,0.3)]">© {new Date().getFullYear()} PepcoLab. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}