'use client'
import { X, ShoppingBag, ArrowRight, Truck, Shield, Plus, Minus, Trash2, Lock } from 'lucide-react'
import { useCart, CartProvider } from '@/lib/cartContext'
import Link from 'next/link'

export default function CartDrawer() {
  const { open, closeCart, lines, totalQuantity, subtotal, removeItem, updateQty, checkout, loading } = useCart()

  const freeShippingThreshold = 75
  const remaining = freeShippingThreshold - subtotal
  const progressPct = Math.min((subtotal / freeShippingThreshold) * 100, 100)

  return (
    <>
      {/* Overlay */}
      {open && (
        <div className="drawer-overlay" onClick={closeCart} />
      )}

      {/* Drawer */}
      <aside className={`drawer ${open ? 'open' : 'closed'}`} aria-label="Shopping cart" aria-hidden={!open}>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--border)]">
          <div className="flex items-center gap-2">
            <ShoppingBag size={17} className="text-[var(--ink)]" />
            <span className="font-medium text-[15px] text-[var(--ink)]">Cart</span>
            {totalQuantity > 0 && (
              <span className="text-[11px] text-[var(--ink-30)] bg-[var(--paper)] border border-[var(--border)] px-2 py-0.5 rounded-full">
                {totalQuantity} {totalQuantity === 1 ? 'item' : 'items'}
              </span>
            )}
          </div>
          <button
            onClick={closeCart}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[var(--paper)] transition-colors text-[var(--ink-30)] hover:text-[var(--ink)]"
          >
            <X size={16} />
          </button>
        </div>

        {/* Free shipping progress */}
        {totalQuantity > 0 && (
          <div className="px-5 py-3 border-b border-[var(--border)] bg-[var(--paper)]">
            {remaining > 0 ? (
              <p className="text-[11.5px] text-[var(--ink-60)] mb-2">
                Add <span className="font-semibold text-[var(--ink)]">£{remaining.toFixed(2)}</span> more for free UK dispatch
              </p>
            ) : (
              <p className="text-[11.5px] text-[var(--green)] font-medium mb-2">
                ✓ You've unlocked free UK dispatch!
              </p>
            )}
            <div className="h-1.5 bg-[var(--border)] rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${progressPct}%`, background: remaining > 0 ? 'var(--cobalt)' : 'var(--green)' }}
              />
            </div>
          </div>
        )}

        {/* Lines */}
        <div className="flex-1 overflow-y-auto">
          {lines.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full px-8 text-center gap-5 py-12">
              <div className="w-16 h-16 rounded-2xl bg-[var(--paper)] border border-[var(--border)] flex items-center justify-center">
                <ShoppingBag size={24} className="text-[var(--ink-30)]" />
              </div>
              <div>
                <p className="text-[15px] font-medium text-[var(--ink)] mb-1.5">Your cart is empty</p>
                <p className="text-[13px] text-[var(--ink-30)] font-light leading-[1.7] max-w-[220px]">
                  Add research peptides to your cart to continue.
                </p>
              </div>
              <button
                onClick={closeCart}
                className="btn btn-ink py-2.5 px-6 gap-2 group"
              >
                Browse Peptides <ArrowRight size={13} className="group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>
          ) : (
            <ul className="divide-y divide-[var(--border)]">
              {lines.map(line => (
                <li key={line.id} className="flex gap-3.5 p-5">
                  {/* Swatch */}
                  <Link
                    href={`/products/${line.slug}`}
                    onClick={closeCart}
                    className="w-16 h-20 rounded-xl bg-[var(--paper)] border border-[var(--border)] flex items-center justify-center flex-shrink-0 text-[11px] font-medium text-[var(--ink-30)] hover:border-[var(--ink-30)] transition-colors"
                  >
                    {line.title.slice(0, 3)}
                  </Link>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <Link
                      href={`/products/${line.slug}`}
                      onClick={closeCart}
                      className="text-[13.5px] font-medium text-[var(--ink)] hover:text-[var(--cobalt)] transition-colors leading-tight block"
                    >
                      {line.title}
                    </Link>
                    <p className="text-[11.5px] text-[var(--ink-30)] mt-0.5 mb-3">{line.variantTitle}</p>

                    {/* Qty + remove */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <button
                          className="qty-btn"
                          onClick={() => updateQty(line.id, line.quantity - 1)}
                          aria-label="Decrease quantity"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="qty-val">{line.quantity}</span>
                        <button
                          className="qty-btn"
                          onClick={() => updateQty(line.id, line.quantity + 1)}
                          aria-label="Increase quantity"
                        >
                          <Plus size={12} />
                        </button>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-[14px] font-semibold text-[var(--ink)]">
                          £{(line.price * line.quantity).toFixed(2)}
                        </span>
                        <button
                          onClick={() => removeItem(line.id)}
                          className="text-[var(--ink-30)] hover:text-[var(--red)] transition-colors"
                          aria-label={`Remove ${line.title} from cart`}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Footer */}
        {lines.length > 0 && (
          <div className="border-t border-[var(--border)] p-5 space-y-4">
            {/* Subtotal */}
            <div className="flex items-center justify-between">
              <span className="text-[13px] text-[var(--ink-60)]">Subtotal</span>
              <span className="text-[18px] font-semibold tracking-tight text-[var(--ink)]">
                £{subtotal.toFixed(2)}
              </span>
            </div>
            <p className="text-[11px] text-[var(--ink-30)]">
              Shipping calculated at checkout. UK dispatch only.
            </p>

            {/* Checkout */}
            <button
              onClick={checkout}
              disabled={loading}
              className="btn btn-cobalt w-full py-3.5 text-[13.5px] gap-2"
            >
              <Lock size={13} />
              {loading ? 'Processing…' : 'Checkout Securely'}
            </button>

            {/* Trust */}
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-1.5 text-[11px] text-[var(--ink-30)]">
                <Truck size={12} className="text-[var(--cobalt)] flex-shrink-0" />
                Cold-chain dispatch
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-[var(--ink-30)]">
                <Shield size={12} className="text-[var(--green)] flex-shrink-0" />
                SSL encrypted
              </div>
            </div>
          </div>
        )}
      </aside>
    </>
  )
}