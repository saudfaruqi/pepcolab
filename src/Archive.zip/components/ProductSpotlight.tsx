import { ArrowRight, ShieldCheck, FileText, Zap } from 'lucide-react'
import Vial from './Vial'

export default function ProductSpotlight() {
  return (
    <section className="py-16 px-6 lg:px-12 border-b border-border">
      <div className="max-w-7xl mx-auto">
        <div className="text-[11px] font-medium tracking-[1.2px] uppercase text-steel-light mb-6">
          Featured this month
        </div>

        {/* Spotlight card */}
        <div className="relative bg-gradient-to-br from-blue-600 to-blue-800 rounded-[20px] overflow-hidden">
          <div className="grid lg:grid-cols-2 gap-0">

            {/* Left */}
            <div className="p-10 lg:p-14 flex flex-col justify-center">
              <span className="inline-flex items-center gap-1.5 text-[10px] font-semibold tracking-[1px] uppercase text-blue-200 bg-white/10 px-3 py-1.5 rounded-full w-fit mb-6">
                Most researched
              </span>
              <h3 className="font-serif text-[42px] lg:text-[50px] leading-[1.05] tracking-[-1.5px] text-white mb-4">
                GLP-1 (Tera)<br />5mg
              </h3>
              <p className="text-[15px] text-blue-200 font-light leading-[1.8] max-w-[360px] mb-6">
                Glucagon-like peptide-1 analogue. Our most-researched metabolic peptide, independently tested to 99.1% purity. HPLC and mass-spec verified. Lot PEP-2412-07.
              </p>

              {/* Data pills */}
              <div className="flex flex-wrap gap-2 mb-8">
                {[
                  { icon: ShieldCheck, label: '99.1% purity' },
                  { icon: FileText, label: 'COA published' },
                  { icon: Zap, label: 'In stock · 34 units' },
                ].map(({ icon: Icon, label }) => (
                  <span key={label} className="flex items-center gap-1.5 text-[12px] text-white bg-white/15 px-3 py-1.5 rounded-full">
                    <Icon size={11} />
                    {label}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-4">
                <div>
                  <div className="text-[32px] font-semibold tracking-tight text-white">£49.99</div>
                  <div className="text-[12px] text-blue-300">+ free dispatch over £75</div>
                </div>
                <a
                  href="/products/glp-1-tera-5mg"
                  className="flex items-center gap-2 bg-white text-blue-700 text-[13px] font-semibold px-6 py-3 rounded-[10px] hover:bg-blue-50 transition-colors btn-press group"
                >
                  View product
                  <ArrowRight size={14} className="group-hover:translate-x-0.5 transition-transform" />
                </a>
              </div>
            </div>

            {/* Right — visual */}
            <div className="relative flex items-center justify-center p-10 overflow-hidden min-h-[300px]">
              {/* Background glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-white/0" />
              <div className="absolute w-64 h-64 rounded-full bg-white/5 blur-3xl" />

              {/* Vials arrangement */}
              <div className="relative flex items-end gap-6 z-10">
                <Vial fromColor="#bfdbfe" toColor="#1d4ed8" mg="5mg" size="lg" className="opacity-60 -translate-y-4" />
                <Vial fromColor="#dbeafe" toColor="#3b82f6" mg="5mg" size="xl" />
                <Vial fromColor="#bfdbfe" toColor="#2563eb" mg="5mg" size="lg" className="opacity-60 translate-y-2" />
              </div>

              {/* Floating data card */}
              <div className="absolute top-8 right-8 bg-white/10 backdrop-blur-sm border border-white/20 rounded-[12px] p-4">
                <div className="text-[9px] font-mono text-blue-200 tracking-wider mb-1.5">PURITY ANALYSIS</div>
                <div className="text-[28px] font-semibold text-white tracking-tight">99.1%</div>
                <div className="text-[10px] text-blue-300 mt-0.5">HPLC verified · Lot PEP-2412-07</div>
                <div className="mt-3 h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full w-[99.1%] bg-white rounded-full" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
